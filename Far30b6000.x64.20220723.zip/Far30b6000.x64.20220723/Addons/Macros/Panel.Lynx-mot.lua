Macro {
  description="LYNX-style motion";
  area="Shell";
  key="Left";
  flags="EmptyCommandLine";
  action = function()
    Keys("CtrlPgUp")
  end;
}

Macro {
  description="LYNX-style motion";
  area="Shell";
  key="Right";
  flags="EmptyCommandLine";
  action = function()
    Keys("CtrlPgDn")
  end;
}
