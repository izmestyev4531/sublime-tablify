Macro {
  description="Open 'Change drive' menu for current panel";
  area="Shell QView Tree Info Search";
  key="Apps";
  action=function()
    Keys("F9 Enter Up Enter")
  end;
}
