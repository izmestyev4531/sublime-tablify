Macro {
  description="Open combobox and history list (as Ctrl+Down pressed)";
  area="Dialog";
  key="AltDown";
  action=function()
    Keys("CtrlDown")
  end;
}
