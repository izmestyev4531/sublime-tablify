Macro {
  description="Use F9 to deactivate main menu";
  area="MainMenu";
  key="F9";
  action=function()
    Keys("Esc")
  end;
}
