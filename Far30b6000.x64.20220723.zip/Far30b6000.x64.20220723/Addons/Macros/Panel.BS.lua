Macro {
  description="Use BS to go to upper folder";
  area="Shell";
  key="BS";
  flags="EmptyCommandLine";
  action=function()
    Keys("CtrlPgUp")
  end;
}
